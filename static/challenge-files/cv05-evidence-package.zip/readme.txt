Evidence package extracted from NexaCore workstation NC-WS-014.
Handle per incident response chain-of-custody procedure.
